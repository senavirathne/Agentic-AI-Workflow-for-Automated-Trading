import json
import logging
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import azure.functions as func

# Ensure the 'src' directory is in the Python path so we can import our project
project_root = Path(__file__).parent.resolve()
src_path = str(project_root / "src")
if src_path not in sys.path:
    sys.path.append(src_path)

from fresh_simple_trading_project.config import Settings
from fresh_simple_trading_project.workflow import build_workflow

app = func.FunctionApp()

DEFAULT_SYMBOL = "AAPL"
DEFAULT_SESSION_LOOPS = 1
SESSION_FILE_NAME = "trading_session.json"


def _utcnow_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _session_path() -> Path:
    settings = Settings.from_env(project_root=project_root)
    return settings.paths.data_dir / SESSION_FILE_NAME


def _inactive_session(symbol: str | None = None) -> dict[str, Any]:
    return {
        "active": False,
        "symbol": (symbol or os.environ.get("TRADING_SYMBOL", DEFAULT_SYMBOL)).upper(),
        "initial_loops": 0,
        "remaining_loops": 0,
        "started_at": None,
        "last_run_at": None,
        "last_result": None,
    }


def _load_session() -> dict[str, Any]:
    session_path = _session_path()
    if not session_path.exists():
        return _inactive_session()

    try:
        session = json.loads(session_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        logging.warning("Trading session file could not be read. Resetting session state.")
        return _inactive_session()

    if "active" not in session or "remaining_loops" not in session:
        return _inactive_session(session.get("symbol"))
    return session


def _save_session(session: dict[str, Any]) -> None:
    session_path = _session_path()
    session_path.parent.mkdir(parents=True, exist_ok=True)
    session_path.write_text(json.dumps(session, indent=2), encoding="utf-8")


def _parse_bool(value: Any, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "y", "on"}


def _parse_positive_int(value: Any, *, default: int) -> int:
    if value in {None, ""}:
        return default
    parsed = int(value)
    if parsed <= 0:
        raise ValueError("loops must be a positive integer")
    return parsed


def _request_payload(req: func.HttpRequest) -> dict[str, Any]:
    try:
        payload = req.get_json()
    except ValueError:
        payload = {}
    return payload if isinstance(payload, dict) else {}


def _request_value(req: func.HttpRequest, payload: dict[str, Any], key: str) -> Any:
    if key in payload:
        return payload[key]
    return req.params.get(key)


def _result_summary(result) -> dict[str, Any]:
    return {
        "symbol": result.symbol,
        "action": result.decision.action.value,
        "quantity": result.decision.quantity,
        "confidence": result.decision.confidence,
        "execution_status": result.execution.status,
        "executed": result.execution.executed,
        "analysis_timestamp": str(result.analysis.timestamp),
    }


def _session_response(
    *,
    message: str,
    session: dict[str, Any],
    status_code: int = 200,
) -> func.HttpResponse:
    body = {
        "message": message,
        "session": session,
    }
    return func.HttpResponse(
        json.dumps(body, indent=2),
        status_code=status_code,
        mimetype="application/json",
    )


def _run_single_iteration(*, symbol: str):
    workflow = build_workflow(project_root=project_root)
    logging.info("Running trade-once for %s", symbol)
    result = workflow.run_once(symbol=symbol, execute_orders=True)
    logging.info(
        "Workflow completed: Decision=%s, Status=%s",
        result.decision.action.value,
        result.execution.status,
    )
    return result


def _complete_session_iteration(session: dict[str, Any], result) -> dict[str, Any]:
    updated = dict(session)
    updated["remaining_loops"] = max(int(updated.get("remaining_loops", 0)) - 1, 0)
    updated["last_run_at"] = _utcnow_iso()
    updated["last_result"] = _result_summary(result)
    updated["active"] = updated["remaining_loops"] > 0
    return updated


# The schedule "0 0 * * * *" means:
# Run at the start (0 seconds, 0 minutes) of every hour.
@app.timer_trigger(schedule="0 0 * * * *", arg_name="myTimer", run_on_startup=False, use_monitor=True)
def trading_timer_trigger(myTimer: func.TimerRequest) -> None:
    if myTimer.past_due:
        logging.info("The timer is past due!")

    session = _load_session()
    if not session.get("active"):
        logging.info("No active trading session. Skipping hourly timer execution.")
        return

    symbol = str(session.get("symbol") or os.environ.get("TRADING_SYMBOL", DEFAULT_SYMBOL)).upper()
    remaining_loops = int(session.get("remaining_loops", 0))
    if remaining_loops <= 0:
        session["active"] = False
        _save_session(session)
        logging.info("Trading session has no remaining loops. Skipping hourly timer execution.")
        return

    logging.info("Hourly trading session execution started for %s. Remaining loops before run: %s", symbol, remaining_loops)
    try:
        result = _run_single_iteration(symbol=symbol)
        session = _complete_session_iteration(session, result)
        _save_session(session)
    except Exception as exc:
        logging.error("Workflow failed with error: %s", str(exc))
        raise

    logging.info(
        "Hourly trading session execution finished. Remaining loops after run: %s",
        session["remaining_loops"],
    )


@app.route(route="trading/session/start", methods=["POST"], auth_level=func.AuthLevel.FUNCTION)
def start_trading_session(req: func.HttpRequest) -> func.HttpResponse:
    payload = _request_payload(req)
    current_session = _load_session()
    force = _parse_bool(_request_value(req, payload, "force"), False)

    if current_session.get("active") and not force:
        return _session_response(
            message="A trading session is already active. Use force=true to replace it.",
            session=current_session,
            status_code=409,
        )

    try:
        loops = _parse_positive_int(
            _request_value(req, payload, "loops"),
            default=int(os.environ.get("TRADING_SESSION_LOOPS", DEFAULT_SESSION_LOOPS)),
        )
    except ValueError as exc:
        return func.HttpResponse(str(exc), status_code=400)

    symbol = str(_request_value(req, payload, "symbol") or os.environ.get("TRADING_SYMBOL", DEFAULT_SYMBOL)).upper()
    run_now = _parse_bool(_request_value(req, payload, "run_now"), True)

    session = {
        "active": True,
        "symbol": symbol,
        "initial_loops": loops,
        "remaining_loops": loops,
        "started_at": _utcnow_iso(),
        "last_run_at": None,
        "last_result": None,
    }

    if not run_now:
        _save_session(session)
        return _session_response(
            message="Trading session started. The first loop will run on the next hourly timer tick.",
            session=session,
            status_code=202,
        )

    logging.info("Manual trading session start requested for %s with %s loop(s).", symbol, loops)
    try:
        result = _run_single_iteration(symbol=symbol)
        session = _complete_session_iteration(session, result)
        _save_session(session)
    except Exception as exc:
        logging.error("Manual trading session start failed with error: %s", str(exc))
        raise

    return _session_response(
        message="Trading session started and the first loop was executed immediately.",
        session=session,
        status_code=202,
    )


@app.route(route="trading/session/stop", methods=["POST"], auth_level=func.AuthLevel.FUNCTION)
def stop_trading_session(req: func.HttpRequest) -> func.HttpResponse:
    session = _load_session()
    session["active"] = False
    session["remaining_loops"] = 0
    _save_session(session)
    return _session_response(
        message="Trading session stopped.",
        session=session,
    )


@app.route(route="trading/session/status", methods=["GET"], auth_level=func.AuthLevel.FUNCTION)
def trading_session_status(req: func.HttpRequest) -> func.HttpResponse:
    return _session_response(
        message="Current trading session status.",
        session=_load_session(),
    )
